# AgriMind Final Build Status

## Included

- React + Vite frontend
- Express + MongoDB backend
- JWT authentication
- Farmer / Buyer role authorization
- Protected frontend routes using `ProtectedRoute`
- Farmer CRUD modules
- Farmer marketplace product management
- Buyer marketplace
- Wishlist
- Cart
- Checkout
- Buyer orders
- Farmer orders
- Reviews
- Notifications
- Profile management
- Government mandi-rate integration hook
- Responsive CSS
- Windows development launcher
- Project setup documentation
- Final project report in `docs/`

## Validation performed

- All backend JavaScript files pass `node --check`.
- All relative frontend imports were checked and resolve to existing source files.
- Main CSS files have balanced braces and parentheses.
- No `node_modules` directories are included in the final archive.

## Important configuration

The project cannot contain your private MongoDB credentials or Government API key. Before running it, create:

```text
server/.env
```

from:

```text
server/.env.example
```

and put your real MongoDB connection string and a private JWT secret there.

The frontend defaults to:

```text
http://localhost:5000/api
```

and can be overridden with:

```text
client/.env
VITE_API_URL=http://localhost:5000/api
```

## Payment

The checkout currently implements Cash on Delivery. The online-payment option is intentionally not connected to a real payment provider because real payment processing requires merchant credentials, webhook verification and provider-side configuration.

## Marketplace order rule

The current order data model represents one farmer per order. Therefore, checkout rejects a cart containing products from multiple farmers. Place separate orders for products belonging to different farmers.
