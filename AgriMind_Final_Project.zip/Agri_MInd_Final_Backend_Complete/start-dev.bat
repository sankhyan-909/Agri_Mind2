@echo off
title AgriMind Development

echo.
echo ==========================================
echo        AGRIMIND DEVELOPMENT SERVER
echo ==========================================
echo.

if not exist "server\node_modules" (
  echo Installing backend dependencies...
  cd server
  call npm install
  cd ..
)

if not exist "client\node_modules" (
  echo Installing frontend dependencies...
  cd client
  call npm install
  cd ..
)

start "AgriMind Backend" cmd /k "cd /d %~dp0server && npm run dev"
start "AgriMind Frontend" cmd /k "cd /d %~dp0client && npm run dev"

echo.
echo Backend:  http://localhost:5000
echo Frontend: http://localhost:5173
echo.
pause
