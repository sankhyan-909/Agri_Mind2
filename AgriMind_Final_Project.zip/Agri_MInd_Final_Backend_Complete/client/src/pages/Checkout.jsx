import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { get, post, put } from "../api";

export default function Checkout() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    paymentMethod: "Cash on Delivery",
  });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [placing, setPlacing] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([get("/shop/cart"), get("/auth/me")])
      .then(([cartResponse, userResponse]) => {
        setItems(cartResponse.data?.items || []);

        const user = userResponse.user;

        setForm((previous) => ({
          ...previous,
          fullName: user.name || "",
          phone: user.phone || "",
          address: user.profile?.address || "",
          city: user.profile?.location || "",
          state: user.profile?.state || "",
          pincode: user.profile?.pincode || "",
        }));
      })
      .catch((error) => {
        setMessage(error.message);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const subtotal = items.reduce(
    (sum, item) =>
      sum +
      Number(item.product?.price || 0) *
        Number(item.quantity || 0),
    0
  );

  const delivery = items.length ? 40 : 0;
  const total = subtotal + delivery;

  const handleChange = (event) => {
    const { name, value } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  const placeOrder = async (event) => {
    event.preventDefault();
    setMessage("");

    if (!items.length) {
      setMessage("Your cart is empty.");
      return;
    }

    if (!/^\d{10}$/.test(form.phone.trim())) {
      setMessage("Please enter a valid 10-digit phone number.");
      return;
    }

    if (!/^\d{6}$/.test(form.pincode.trim())) {
      setMessage("Please enter a valid 6-digit PIN code.");
      return;
    }

    setPlacing(true);

    try {
      const response = await post("/orders", {
        items: items.map((item) => ({
          productId: item.product?._id,
          quantity: Number(item.quantity),
        })),
        customer: form,
        paymentMethod: form.paymentMethod,
      });

      await put("/shop/cart", {
        items: [],
      });

      setMessage(
        response.data?.orderNumber
          ? `Order ${response.data.orderNumber} placed successfully.`
          : "Order placed successfully."
      );

      setTimeout(() => {
        navigate("/buyer-orders", { replace: true });
      }, 500);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="checkout-page">
      <nav className="checkout-navbar">
        <Link to="/buyer-dashboard">🌾 AgriMind</Link>
        <Link to="/cart">← Cart</Link>
      </nav>

      <main className="checkout-main">
        <div className="checkout-heading">
          <span>SECURE CHECKOUT</span>
          <h1>Complete Your Order</h1>
          <p>
            Your order is saved in MongoDB and appears in the
            buyer and farmer order portals.
          </p>
        </div>

        {message && (
          <div className="save-message">✓ {message}</div>
        )}

        {loading ? (
          <p>Loading checkout...</p>
        ) : items.length === 0 ? (
          <div className="cart-empty">
            <div className="cart-empty-icon">🛒</div>
            <h2>Your cart is empty</h2>
            <p>Add products before proceeding to checkout.</p>
            <Link
              to="/buyer-dashboard"
              className="cart-empty-button"
            >
              Explore Marketplace
            </Link>
          </div>
        ) : (
          <div className="checkout-layout">
            <form
              className="checkout-form"
              onSubmit={placeOrder}
            >
              <h2>Delivery Details</h2>

              <div className="checkout-form-grid">
                <label>
                  Full Name
                  <input
                    name="fullName"
                    required
                    value={form.fullName}
                    onChange={handleChange}
                  />
                </label>

                <label>
                  Phone
                  <input
                    name="phone"
                    required
                    inputMode="numeric"
                    maxLength="10"
                    value={form.phone}
                    onChange={handleChange}
                  />
                </label>

                <label className="full">
                  Address
                  <input
                    name="address"
                    required
                    value={form.address}
                    onChange={handleChange}
                  />
                </label>

                <label>
                  City
                  <input
                    name="city"
                    required
                    value={form.city}
                    onChange={handleChange}
                  />
                </label>

                <label>
                  State
                  <input
                    name="state"
                    required
                    value={form.state}
                    onChange={handleChange}
                  />
                </label>

                <label>
                  Pincode
                  <input
                    name="pincode"
                    required
                    inputMode="numeric"
                    maxLength="6"
                    value={form.pincode}
                    onChange={handleChange}
                  />
                </label>
              </div>

              <h2>Payment</h2>

              <label className="payment-option">
                <input
                  type="radio"
                  checked={
                    form.paymentMethod ===
                    "Cash on Delivery"
                  }
                  onChange={() =>
                    setForm((previous) => ({
                      ...previous,
                      paymentMethod: "Cash on Delivery",
                    }))
                  }
                />
                Cash on Delivery
              </label>

              <button
                className="checkout-button"
                disabled={placing}
              >
                {placing
                  ? "Placing Order..."
                  : "Place Order →"}
              </button>
            </form>

            <aside className="checkout-summary">
              <h2>Order Summary</h2>

              {items.map((item) => (
                <div
                  className="checkout-summary-item"
                  key={item.product._id}
                >
                  <span>
                    {item.product.name} × {item.quantity}
                  </span>

                  <strong>
                    ₹
                    {(
                      item.product.price *
                      item.quantity
                    ).toFixed(2)}
                  </strong>
                </div>
              ))}

              <div className="cart-summary-row">
                <span>Subtotal</span>
                <strong>₹{subtotal.toFixed(2)}</strong>
              </div>

              <div className="cart-summary-row">
                <span>Delivery</span>
                <strong>₹{delivery.toFixed(2)}</strong>
              </div>

              <div className="cart-summary-total">
                <span>Total</span>
                <strong>₹{total.toFixed(2)}</strong>
              </div>
            </aside>
          </div>
        )}
      </main>
    </div>
  );
}
