# AgriMind Backend Status

The `server` folder contains the complete REST API backend:
- JWT + bcrypt authentication
- MongoDB/Mongoose models
- Farmer farm/crop/inventory/expense/income/harvest/fertilizer/irrigation CRUD
- Marketplace products
- Buyer/farmer orders
- Reviews
- Government/market reference rates
- Profile/password APIs

## Before running

Create `server/.env` from `server/.env.example` and put your MongoDB Atlas connection string there.

The package intentionally does not include any database password.

## Run

From `server`:

```bash
npm install
npm run dev
```
